# Reproduction materials for Problem D

Team apmcm26308551. The manuscript uses the official APMCM class.

| File | Contents |
|---|---|
| [main.tex](main.tex) | Editable manuscript entry point |
| [artifacts/q1_holdout.csv](artifacts/q1_holdout.csv) | 3,703 composition-only Q1 predictions, trained on 02 |
| [artifacts/q23_full.csv](artifacts/q23_full.csv) | 8,112 frozen predictions from the 02+03 refit, including every Q2 row |
| [artifacts/score_runs.csv](artifacts/score_runs.csv) | SHA-256 digests and feature, fitting and prediction times |
| [artifacts/selections.csv](artifacts/selections.csv) | Exact Kaiwu selections for pools 07 and 08, pool runners-up and enumeration gaps |
| [artifacts/blind_minima.csv](artifacts/blind_minima.csv) | Direct scans of blind subsets 11 and 12 |
| [artifacts/block_runs.csv](artifacts/block_runs.csv) | All 338 nine-spin calls, block indices (alphabetical element order), ground-state tie counts, original scores and timings |
| [artifacts/group_folds.csv](artifacts/group_folds.csv) | Five-fold grouped development results |
| [artifacts/capacity_control.csv](artifacts/capacity_control.csv) | Matched-descriptor direct fits with 350, 700 and 1,050 trees versus the frozen mixture, two seeds and three pools |
| [artifacts/q2_blind_comparison.csv](artifacts/q2_blind_comparison.csv) | All 529 blind Q2 IDs, four predicted properties, both seed-26 scores and ranks after fitting on 02+03 |
| [artifacts/costs.csv](artifacts/costs.csv) | Timings, calls, integer ranges and tie counts |

The paper contains ten figures in the main text and two in the appendix. Each is a native vector PDF made from the underlying data or ideal cubic coordinates. The [workflow](figures/workflow.pdf) traces the two uses of file 03 and the full and blind searches. The [paired unit cells](figures/crystal_sites.pdf) exchange the A and B species at fixed fractional coordinates. The [Q3 budget comparison](figures/q3_budget.pdf) shows both 50-candidate hit counts and rank-one regret on the same 1,701 validation rows for seeds 26 and 42, including the 1,050-tree direct baseline. The [integer tie example](figures/tied_block.pdf) links four minimum-cost cells to their original scores. Model colors, markers and element colors are shared across figures. The [three-family score maps](figures/family_landscapes.pdf) are a further figure in the supporting archive.

The gate replay checks the 3,969 archived seed-26 predictions. The separate capacity control replays the direct and mixture baselines for seeds 26 and 42, then refits larger direct models on file 02. Its 700-tree budget matches nominal training-row passes and its 1,050-tree budget matches the mixture's component tree count. Fitting times are measured separately for each run. Pair-bootstrap and seed-overlap results appear in [shortlist_sensitivity.csv](artifacts/shortlist_sensitivity.csv).

## Reproduce the numbers

From the repository root, use a Python 3.12 environment with the packages listed in `problem_d/requirements-lock.txt`. Keep all original D CSV files and the organizer's SHA-256 manifest and data notes in `problem_d/date/`. If starting from the support archive, supply this folder from the competition download. The official manifest also includes the original Chinese-named data notes.

The commands below use PowerShell and assume that `python` invokes the selected environment. Timing columns depend on machine load. With the repository or extracted support ZIP, the stored results are sufficient to compile the paper. Regenerating plots that read public properties or rerunning the experiments also requires the organizer’s original CSV files.

```powershell
python problem_d/exploration/audit_data.py
foreach ($seed in 26,42) {
    python problem_d/exploration/compare_surrogates.py --seed $seed --predictions "problem_d/results/validation_seed$seed.csv"
    python problem_d/exploration/test_innovation_ideas.py stress --seed $seed --predictions "problem_d/results/stress_seed$seed.csv"
    python problem_d/exploration/compare_physical_properties.py --seed $seed --predictions "problem_d/results/physical_seed$seed.csv"
}
python problem_d/exploration/test_innovation_ideas.py encoding --seed 26 --predictions problem_d/results/encoding_seed26.csv
python problem_d/exploration/audit_sdk_precision.py
python problem_d/paper/screen.py scores
python problem_d/paper/screen.py development
python problem_d/paper/solve.py
python problem_d/paper/gate_audit.py
python problem_d/paper/capacity_audit.py
python problem_d/paper/q2_blind_comparison.py
python problem_d/paper/mechanisms.py
python problem_d/paper/tables.py
```

The numerical lock includes Matplotlib 3.10.3. All final vector figures use Matplotlib 3.10.8. With the locked numerical environment active, run the following in a separate PowerShell session from the repository root. The temporary package directory selects the rendering version for this session while reusing the locked numerical packages.

```powershell
$renderLib = Join-Path $env:TEMP 'apmcm-render-mpl3108'
python -m pip install --no-deps --target $renderLib matplotlib==3.10.8
$env:PYTHONPATH = $renderLib
python -c "import matplotlib; assert matplotlib.__version__ == '3.10.8'"
python problem_d/paper/figures.py
python problem_d/paper/material_figures.py
python problem_d/paper/perovskite_plates.py
python problem_d/paper/crystal_scenes.py
```

The Q1 predictions use seed 26 and the 02-only model. The Q2/Q3 refit uses the same seed and features. The SDK's public exact CPU solver works on these small blocks without interactive activation in the tested installation. The separate simulated-annealing backend prompted for official authorization. The paper's cost comparison uses the CPU backend.

## Compile the manuscript

With TeX Live and the APMCM template dependencies installed, run from this directory in PowerShell. The template class and configuration are included under `sources/latex/`. Install the template dependencies, including ctex, xeCJK, ulem, cprotect, bigfoot, appendix, placeins and needspace. The class uses Times New Roman when installed, then tries TeX Gyre Termes and Liberation Serif. Page breaks can vary with the chosen font.

```powershell
$env:TEXINPUTS = '.;../../sources/latex;' + $env:TEXINPUTS + ';'
xelatex -halt-on-error -interaction=nonstopmode -jobname=Dapmcm26308551 main.tex
xelatex -halt-on-error -interaction=nonstopmode -jobname=Dapmcm26308551 main.tex
xelatex -halt-on-error -interaction=nonstopmode -jobname=Dapmcm26308551 main.tex
```

## Additional experiments

Run `second_audit.py` for in-training residual diagnostics, the Q1 distribution,
the top-20 table and the logged whole-grid annealing attempt. Run `blind_solve.py`
for the membership-constrained Q2 property-first and Q3 mixture selections.
The exact CPU solves completed; simulated annealing requested SDK authorization
and returned no samples. No stochastic success rate is available.
